<?php
    if(isset($_GET["sucesso"])){
        $sucesso = $_GET["sucesso"];
        if($sucesso == "sim"){
            echo "Usuário cadastrado com sucesso!";
    }
}