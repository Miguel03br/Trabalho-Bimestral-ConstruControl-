<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <h2>Faça seu login logo abaixo</h2>
        <input type="text" name="email" placeholder="Digite seu e-mail">
        <input type="password" name="senha" placeholder="Digite sua senha">
        <input type="submit" value="enviar">
    </form>

    <?php
        if(isset($_POST["email"]) && isset($_POST["senha"]) && !empty($_POST["email"]) && !empty($_POST["senha"])){
            require "conexaoBD.php";
            $email = $_POST["email"];
            $senha = $_POST["senha"];
            $sql = "INSERT INTO login(email, senha) VALUES (:email, :senha)";
            $resultado = $conn->prepare($sql);
            $resultado = bindValue("email", "$email");
            $resultado = bindValue("senha", "$senha");
            $resultado -> execute();
            header("verificarLogin?sucesso=sim");

        }
    ?>
</body>
</html>